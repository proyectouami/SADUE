package test.mx.uam.ayd.sadue.datos;

import junit.framework.TestCase;

public class DAOProductosTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testDAOProductos() {
		fail("Not yet implemented");
	}

	public void testAgregaProducto() {
		fail("Not yet implemented");
	}

	public void testQuitaProducto() {
		fail("Not yet implemented");
	}

	public void testActualizaProducto() {
		fail("Not yet implemented");
	}

	public void testBuscaProductoIntString() {
		fail("Not yet implemented");
	}

	public void testBuscaProductoIntStringString() {
		fail("Not yet implemented");
	}

	public void testDameExistencia() {
		fail("Not yet implemented");
	}

	public void testBuscaProductoString() {
		fail("Not yet implemented");
	}

	public void testBuscaProductoInt() {
		fail("Not yet implemented");
	}

	public void testDameProductos() {
		fail("Not yet implemented");
	}

	public void testDameProductosString() {
		fail("Not yet implemented");
	}

	public void testCuantosProductos() {
		fail("Not yet implemented");
	}

}
